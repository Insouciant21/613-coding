"""Convert between integers and canonical Roman numerals."""

_VALUES = (
    (1000, "M"),
    (900, "CM"),
    (500, "D"),
    (400, "CD"),
    (100, "C"),
    (90, "XC"),
    (50, "L"),
    (40, "XL"),
    (10, "X"),
    (9, "IX"),
    (5, "V"),
    (4, "IV"),
    (1, "I"),
)


def to_roman(n: int) -> str:
    """Return the canonical uppercase Roman numeral for an integer."""
    if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= 3999:
        raise ValueError("Roman numerals support integers from 1 through 3999")

    result = []
    for value, numeral in _VALUES:
        count, n = divmod(n, value)
        result.append(numeral * count)
    return "".join(result)


def from_roman(s: str) -> int:
    """Parse a canonical uppercase Roman numeral into an integer."""
    if not isinstance(s, str) or not s:
        raise ValueError("invalid Roman numeral")

    total = 0
    index = 0
    for value, numeral in _VALUES:
        while s.startswith(numeral, index):
            total += value
            index += len(numeral)

    if index != len(s) or to_roman(total) != s:
        raise ValueError("invalid Roman numeral")
    return total

