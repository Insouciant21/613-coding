"""Command-line interface for :mod:`romannum`."""

import argparse
import sys

from . import to_roman


def main() -> int:
    parser = argparse.ArgumentParser(prog="python -m romannum")
    parser.add_argument("number")
    args = parser.parse_args()

    try:
        number = int(args.number)
        print(to_roman(number))
    except (ValueError, TypeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

