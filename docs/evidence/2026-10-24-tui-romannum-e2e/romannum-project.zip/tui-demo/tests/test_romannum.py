"""Acceptance tests for romannum, authored by the operator before the TUI run."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

import pytest

from romannum import from_roman, to_roman

REPO = Path(__file__).resolve().parent.parent


def test_to_roman_basics() -> None:
    assert to_roman(2026) == "MMXXVI"
    assert to_roman(9) == "IX"
    assert to_roman(3999) == "MMMCMXCIX"


def test_to_roman_rejects_out_of_range() -> None:
    with pytest.raises(ValueError):
        to_roman(0)
    with pytest.raises(ValueError):
        to_roman(4000)


def test_from_roman_parses_and_validates() -> None:
    assert from_roman("MMXXVI") == 2026
    with pytest.raises(ValueError):
        from_roman("ix")  # lowercase is invalid input
    with pytest.raises(ValueError):
        from_roman("IIII")  # non-canonical repetition


def test_roundtrip_one_to_two_hundred() -> None:
    for value in range(1, 201):
        assert from_roman(to_roman(value)) == value


def test_cli_converts_and_rejects() -> None:
    ok = subprocess.run(
        [sys.executable, "-m", "romannum", "2026"], cwd=REPO, capture_output=True, text=True, timeout=30
    )
    assert ok.returncode == 0, ok.stderr
    assert ok.stdout.strip() == "MMXXVI"
    bad = subprocess.run(
        [sys.executable, "-m", "romannum", "abc"], cwd=REPO, capture_output=True, text=True, timeout=30
    )
    assert bad.returncode == 2
