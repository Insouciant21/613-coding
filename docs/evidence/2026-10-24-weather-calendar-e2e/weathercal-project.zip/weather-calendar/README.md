# weathercal

天气日历：把本地天气记录渲染成月历，并输出月度统计。仅使用 Python 标准库。
