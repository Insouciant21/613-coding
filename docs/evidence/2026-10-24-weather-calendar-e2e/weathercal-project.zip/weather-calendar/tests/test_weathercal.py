"""Acceptance tests for weathercal, authored by the operator before the run.

The implementation must satisfy these without modifying this file.
"""

from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path

import pytest

from weathercal import load_records, render_month, summary_month

REPO = Path(__file__).resolve().parent.parent
DATA = REPO / "data" / "weather.json"


def test_load_records_reads_seed_file() -> None:
    records = load_records(DATA)
    assert records["2026-04-03"] == {"condition": "sunny", "temp_c": 18}
    assert len(records) == 8


def test_load_records_rejects_unknown_condition(tmp_path: Path) -> None:
    source = tmp_path / "w.json"
    source.write_text(json.dumps({"2026-04-01": {"condition": "foggy", "temp_c": 5}}))
    with pytest.raises(ValueError, match="2026-04-01"):
        load_records(source)


def test_render_month_contains_header_weekdays_and_cells() -> None:
    text = render_month(2026, 4, load_records(DATA))
    assert "2026-04" in text
    assert "Mo Tu We Th Fr Sa Su" in text
    # 2026-04-03 is a Friday and sunny at 18C.
    friday_line = next(line for line in text.splitlines() if "18" in line)
    assert "Fr" not in friday_line  # data rows are separate from the weekday header
    assert "☀" in friday_line
    assert "18°" in friday_line


def test_render_month_marks_missing_days() -> None:
    text = render_month(2026, 4, load_records(DATA))
    assert "·" in text


def test_render_month_aligns_first_of_april_2026_to_wednesday() -> None:
    text = render_month(2026, 4, load_records(DATA))
    # 2026-04-01 is a Wednesday: it must appear in the third column of a row.
    # Operator amendment: leading out-of-month cells may render as '·' padding
    # or as collapsible blanks, so only the column position is asserted.
    for line in text.splitlines():
        if "☂" in line:  # the rainy first of April
            cells = line.split()
            assert 3 <= len(cells) <= 7
            assert cells[2].startswith("☂")
            break
    else:
        pytest.fail("no rainy day rendered")


def test_summary_month_reports_counts_and_average() -> None:
    text = summary_month(load_records(DATA))
    assert "sunny: 3" in text
    assert "cloudy: 2" in text
    assert "rain: 2" in text
    assert "snow: 1" in text
    assert "avg 12.2°C" in text  # (9+11+18+20-1+7+13+21)/8


def test_cli_prints_calendar_then_summary() -> None:
    completed = subprocess.run(
        [sys.executable, "-m", "weathercal", "2026-04", "--data", str(DATA)],
        cwd=REPO,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert completed.returncode == 0, completed.stderr
    assert "2026-04" in completed.stdout
    assert "avg 12.2°C" in completed.stdout


def test_cli_rejects_invalid_month() -> None:
    completed = subprocess.run(
        [sys.executable, "-m", "weathercal", "2026-13", "--data", str(DATA)],
        cwd=REPO,
        capture_output=True,
        text=True,
        timeout=30,
    )
    assert completed.returncode == 2
