"""Weather calendar rendering and summary helpers."""

from __future__ import annotations

import calendar
import json
from datetime import date
from pathlib import Path
from typing import Any, Mapping


_CONDITIONS = ("sunny", "cloudy", "rain", "snow")
_ICONS = {
    "sunny": "☀",
    "cloudy": "☁",
    "rain": "☂",
    "snow": "❄",
}


def load_records(path: str | Path) -> dict[str, dict[str, Any]]:
    """Load and validate weather records from a JSON file."""
    with Path(path).open(encoding="utf-8") as handle:
        data = json.load(handle)

    if not isinstance(data, dict):
        raise ValueError("weather data must be a JSON object")

    records: dict[str, dict[str, Any]] = {}
    for record_date, record in data.items():
        if not isinstance(record_date, str):
            raise ValueError(f"invalid date {record_date!r}")
        try:
            parsed_date = date.fromisoformat(record_date)
        except ValueError as exc:
            raise ValueError(f"invalid date {record_date}") from exc
        if parsed_date.isoformat() != record_date:
            raise ValueError(f"invalid date {record_date}")
        if not isinstance(record, dict):
            raise ValueError(f"invalid record for {record_date}")

        condition = record.get("condition")
        if condition not in _CONDITIONS:
            raise ValueError(f"invalid condition for {record_date}: {condition!r}")
        temperature = record.get("temp_c")
        if isinstance(temperature, bool) or not isinstance(temperature, int):
            raise ValueError(f"invalid temperature for {record_date}")
        records[record_date] = {"condition": condition, "temp_c": temperature}

    return records


def render_month(
    year: int, month: int, records: Mapping[str, Mapping[str, Any]]
) -> str:
    """Render a month as a Monday-first text calendar."""
    if not 1 <= month <= 12:
        raise ValueError("month must be between 1 and 12")

    lines = [f"{year:04d}-{month:02d}", "Mo Tu We Th Fr Sa Su"]
    month_calendar = calendar.Calendar(firstweekday=calendar.MONDAY)
    for week in month_calendar.monthdayscalendar(year, month):
        cells = []
        for day_number in week:
            if day_number == 0:
                cells.append("·")
                continue
            record_date = f"{year:04d}-{month:02d}-{day_number:02d}"
            record = records.get(record_date)
            if record is None:
                cells.append("·")
            else:
                condition = record["condition"]
                cells.append(f"{_ICONS[condition]}{record['temp_c']}°")
        lines.append(" ".join(cells))
    return "\n".join(lines)


def summary_month(records: Mapping[str, Mapping[str, Any]]) -> str:
    """Summarize the supplied weather records by condition and temperature."""
    counts = {condition: 0 for condition in _CONDITIONS}
    temperatures = []
    for record in records.values():
        condition = record["condition"]
        counts[condition] += 1
        temperatures.append(record["temp_c"])

    lines = [
        f"{condition}: {counts[condition]}"
        for condition in _CONDITIONS
        if counts[condition]
    ]
    average = sum(temperatures) / len(temperatures) if temperatures else 0.0
    lines.append(f"avg {average:.1f}°C")
    return "\n".join(lines)
