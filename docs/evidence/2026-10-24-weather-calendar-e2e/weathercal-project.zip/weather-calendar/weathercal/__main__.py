"""Command-line entry point for :mod:`weathercal`."""

from __future__ import annotations

import argparse
import sys
from datetime import datetime
from pathlib import Path

from . import load_records, render_month, summary_month


def _parse_month(value: str) -> tuple[int, int]:
    try:
        parsed = datetime.strptime(value, "%Y-%m")
    except ValueError as exc:
        raise argparse.ArgumentTypeError("month must be in YYYY-MM format") from exc
    if parsed.strftime("%Y-%m") != value:
        raise argparse.ArgumentTypeError("month must be in YYYY-MM format")
    return parsed.year, parsed.month


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="python -m weathercal")
    parser.add_argument("month", type=_parse_month)
    parser.add_argument("--data", type=Path, default=Path("data/weather.json"))
    args = parser.parse_args(argv)

    try:
        records = load_records(args.data)
        year, month = args.month
        calendar_text = render_month(year, month, records)
        summary_text = summary_month(records)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        parser.error(str(exc))

    print(calendar_text)
    print(summary_text)
    return 0


if __name__ == "__main__":
    sys.exit(main())

