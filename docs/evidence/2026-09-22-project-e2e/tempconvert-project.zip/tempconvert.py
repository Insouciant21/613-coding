"""Convert temperatures between Celsius, Fahrenheit, and Kelvin.

Run ``python -m tempconvert VALUE SOURCE TARGET`` for the command-line
interface.
"""

import math
import sys
from typing import Sequence


_UNITS = {"C", "F", "K"}
_ABSOLUTE_ZERO_C = -273.15


def _normalise_unit(unit: str) -> str:
    """Return a validated, uppercase temperature unit."""
    if not isinstance(unit, str):
        raise ValueError("temperature unit must be C, F, or K")
    normalised = unit.upper()
    if normalised not in _UNITS:
        raise ValueError("temperature unit must be C, F, or K")
    return normalised


def convert(value: float, source: str, target: str) -> float:
    """Convert a finite temperature between C, F, and K.

    ``ValueError`` is raised for invalid units, non-finite values, and values
    below absolute zero in the source scale.
    """
    source_unit = _normalise_unit(source)
    target_unit = _normalise_unit(target)

    try:
        temperature = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError("temperature value must be a finite number") from exc
    if not math.isfinite(temperature):
        raise ValueError("temperature value must be a finite number")

    if source_unit == "C":
        celsius = temperature
    elif source_unit == "F":
        celsius = (temperature - 32) * 5 / 9
    else:
        celsius = temperature - 273.15

    # A small tolerance prevents floating-point representations of exact
    # absolute-zero values (notably -459.67 F) from being rejected.
    if celsius < _ABSOLUTE_ZERO_C and not math.isclose(
        celsius, _ABSOLUTE_ZERO_C, abs_tol=1e-12
    ):
        raise ValueError("temperature cannot be below absolute zero")
    celsius = max(celsius, _ABSOLUTE_ZERO_C)

    if target_unit == "C":
        return celsius
    if target_unit == "F":
        return celsius * 9 / 5 + 32
    return celsius + 273.15


def main(argv: Sequence[str] | None = None) -> int:
    """Run the command-line interface and return its process status."""
    arguments = list(sys.argv[1:] if argv is None else argv)
    if len(arguments) != 3:
        print("usage: python -m tempconvert VALUE SOURCE TARGET", file=sys.stderr)
        return 2

    value, source, target = arguments
    try:
        result = convert(value, source, target)
        target_unit = _normalise_unit(target)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    print(f"{result:.2f} {target_unit}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
