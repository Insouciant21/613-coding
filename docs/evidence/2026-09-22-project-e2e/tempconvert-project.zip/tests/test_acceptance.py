import math
import subprocess
import sys
import unittest
from tempconvert import convert

class Acceptance(unittest.TestCase):
    def test_celsius_fahrenheit(self):
        self.assertAlmostEqual(convert(100, "C", "F"), 212)
        self.assertAlmostEqual(convert(32, "F", "C"), 0)
    def test_kelvin(self):
        self.assertAlmostEqual(convert(0, "C", "K"), 273.15)
        self.assertAlmostEqual(convert(273.15, "K", "C"), 0)
        self.assertAlmostEqual(convert(98.6, "F", "K"), 310.15)
    def test_case_and_identity(self):
        self.assertAlmostEqual(convert(10, "c", "c"), 10)
        self.assertAlmostEqual(convert(-40, "c", "f"), -40)
    def test_absolute_zero(self):
        self.assertAlmostEqual(convert(-273.15, "C", "K"), 0, places=8)
        self.assertAlmostEqual(convert(-459.67, "F", "K"), 0, places=8)
    def test_below_absolute_zero(self):
        for value, unit in [(-274,"C"),(-1,"K"),(-460,"F")]:
            with self.subTest(unit=unit), self.assertRaises(ValueError):
                convert(value, unit, "K")
    def test_invalid_identity(self):
        with self.assertRaises(ValueError):
            convert(-1, "K", "K")
    def test_unknown_unit(self):
        for source,target in [("X","C"),("C","X")]:
            with self.assertRaises(ValueError):
                convert(10, source, target)
    def test_nonfinite(self):
        for value in [math.nan, math.inf, -math.inf]:
            with self.assertRaises(ValueError):
                convert(value, "C", "K")
    def test_cli_success(self):
        result=subprocess.run([sys.executable,"-m","tempconvert","100","c","f"],capture_output=True,text=True)
        self.assertEqual(result.returncode,0,result.stderr)
        self.assertEqual(result.stdout.strip(),"212.00 F")
    def test_cli_failure(self):
        for args in [("oops","C","F"),("-1","K","C"),("nan","C","F")]:
            result=subprocess.run([sys.executable,"-m","tempconvert",*args],capture_output=True,text=True)
            self.assertNotEqual(result.returncode,0)
            self.assertTrue(result.stderr)
            self.assertNotIn("Traceback",result.stderr)
