"""Additional coverage for TempConvert's documented behavior."""

import math
import unittest

from tempconvert import convert


class ConvertExtraTests(unittest.TestCase):
    def test_units_are_case_insensitive(self):
        self.assertAlmostEqual(convert(32, "f", "c"), 0)
        self.assertAlmostEqual(convert(0, "c", "k"), 273.15)

    def test_identity_conversion_validates_absolute_zero(self):
        with self.assertRaises(ValueError):
            convert(-1, "K", "K")

    def test_non_finite_values_are_rejected(self):
        for value in (math.nan, math.inf, -math.inf):
            with self.subTest(value=value):
                with self.assertRaises(ValueError):
                    convert(value, "C", "F")

    def test_fahrenheit_absolute_zero_is_accepted(self):
        self.assertAlmostEqual(convert(-459.67, "F", "K"), 0)
