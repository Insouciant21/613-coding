# TempConvert project requirements
Implement a standard-library-only Python module tempconvert.py.
Public API: convert(value: float, source: str, target: str) -> float.
Units C/F/K are case insensitive. Kelvin absolute zero is 0, Celsius -273.15,
Fahrenheit -459.67. Reject unknown units, NaN/infinity, and temperatures below
absolute zero with ValueError. Identity conversions must also validate inputs.
CLI: python -m tempconvert VALUE SOURCE TARGET. Print exactly two decimal
places, a space, and the uppercase target unit, e.g. 212.00 F. Invalid inputs
must produce a nonzero exit and an error on stderr, without a traceback.
Add usage examples and at least three extra unit tests in tests/test_extra.py.
Do not modify tests/test_acceptance.py or harness.toml. No external dependencies.
Run the configured unittest discovery validation, repair failures, and finish.

## Examples

Use the public API from Python:

```python
from tempconvert import convert

assert convert(100, "C", "F") == 212.0
assert convert(32, "f", "k") == 273.15
```

Use the command-line interface with a value, source unit, and target unit:

```console
$ python -m tempconvert 100 C F
212.00 F

$ python -m tempconvert 273.15 K c
0.00 C
```

Units are `C`, `F`, and `K` (case insensitive). Invalid units, non-finite
numbers, and values below absolute zero result in an error and nonzero exit
status.
